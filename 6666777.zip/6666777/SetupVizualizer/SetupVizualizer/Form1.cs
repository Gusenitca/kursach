﻿using System;  // Импорт пространства имен для работы с основными типами данных
using System.IO;  // Импорт пространства имен для работы с файловой системой
using System.Threading;  // Импорт пространства имен для работы с потоками
using System.Threading.Tasks;  // Импорт пространства имен для работы с асинхронными задачами
using System.Windows.Forms;  // Импорт пространства имен для работы с элементами управления Windows Forms

namespace SetupVizualizer
{
    public partial class Form1 : Form
    {
        private const string ProgramName = "VizualizerSorting";  // Константа с названием программы
        private readonly string ReadMe =  // Текст руководства пользователя
            $"Руководство пользователя:" + Environment.NewLine +
            "1) Запустите программу" + Environment.NewLine +
            "2) Загрузите список строк для сортировки" + Environment.NewLine +
            "3) Нажмите одну из кнопок";

        public Form1()
        {
            InitializeComponent();  // Инициализация компонентов формы
        }

        // Обработчик события для кнопки установки программы
        private async void buttonInstall_Click(object sender, EventArgs e)
        {
            // Асинхронный запуск установки в фоновом потоке
            await Task.Run(() =>
            {
                // Получение пути для установки из текстового поля
                string path = textBoxPath.Text;

                // Проверка, содержит ли путь название программы, если нет - добавляем
                if (!path.Contains(ProgramName))
                {
                    path = Path.Combine(path, ProgramName);
                }

                // Установка значения прогрессбара на 15%
                Thread.Sleep(300);
                progressBar1.Value = 15;

                try
                {
                    // Создание директории для установки программы
                    Directory.CreateDirectory(path);
                }
                catch (Exception)
                {
                    // Если произошла ошибка, устанавливаем прогрессбар в 0 и выводим сообщение об ошибке
                    progressBar1.Value = 0;
                    MessageBox.Show("Установка программы в выбранную папку невозможна.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Выход из метода в случае ошибки
                }

                // Установка значения прогрессбара на 35%
                Thread.Sleep(700);
                progressBar1.Value = 35;

                // Создание пути к файлу ReadMe.txt и запись в него текста ReadMe
                string readmePath = Path.Combine(path, "ReadMe.txt");
                File.WriteAllText(readmePath, ReadMe);

                // Установка значения прогрессбара на 45%
                Thread.Sleep(1500);
                progressBar1.Value = 45;

                // Создание пути для установки exe-файла
                path = Path.Combine(path, $"{ProgramName}.exe");

                // Запись бинарных данных программы в exe-файл
                File.WriteAllBytes(path, Properties.Resources.VizualizerSortArray);

                // Установка значения прогрессбара на 100%
                Thread.Sleep(2300);
                progressBar1.Value = 100;

                // Вывод сообщения об успешной установке
                MessageBox.Show("Установка завершена. Это окно будет закрыто.", "Успешно!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();  // Закрытие формы после установки
            });
        }

        // Обработчик события для чекбокса, активирующего кнопку установки
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            buttonInstall.Enabled = checkBox1.Checked;
        }

        // Обработчик события для кнопки выбора папки
        private void buttonSelectFolder_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
            {
                DialogResult result = folderBrowserDialog.ShowDialog();

                if (result == DialogResult.OK)
                {
                    textBoxPath.Text = folderBrowserDialog.SelectedPath;
                }
            }
        }
    }
}
